DROP TABLE IF EXISTS appuser CASCADE; 
DROP TABLE IF EXISTS course CASCADE; 
DROP TABLE IF EXISTS appuser_course CASCADE;
DROP TABLE IF EXISTS exam CASCADE; 
DROP TABLE IF EXISTS course_exam CASCADE; 
DROP TABLE IF EXISTS question CASCADE; 
DROP TABLE IF EXISTS choice CASCADE; 
DROP TABLE IF EXISTS exam_appuser_choice CASCADE;  

CREATE TABLE appuser (
	id SERIAL PRIMARY KEY,
	name TEXT,
	email TEXT,
	password TEXT,
	usertype TEXT
);

CREATE TABLE course (
	id SERIAL PRIMARY KEY, 
	name TEXT
);

CREATE TABLE appuser_course (
	id_appuser BIGINT,
	id_course BIGINT,
	PRIMARY KEY (id_appuser, id_course),
	FOREIGN KEY (id_appuser)
		REFERENCES appuser(id)
			ON UPDATE CASCADE
			ON DELETE CASCADE,
	FOREIGN KEY (id_course)
		REFERENCES course(id)
			ON UPDATE CASCADE
			ON DELETE CASCADE
); 

CREATE TABLE exam (
	id SERIAL PRIMARY KEY,
	name TEXT,
	id_appuser BIGINT,
	FOREIGN KEY (id_appuser)
		REFERENCES appuser(id)
			ON UPDATE CASCADE
			ON DELETE CASCADE
);

CREATE TABLE course_exam (
	id_course BIGINT,
	id_exam BIGINT,
	PRIMARY KEY (id_course, id_exam),
	FOREIGN KEY (id_course)
		REFERENCES course(id)
			ON UPDATE CASCADE
			ON DELETE CASCADE,
	FOREIGN KEY (id_exam)
		REFERENCES exam(id)
			ON UPDATE CASCADE
			ON DELETE CASCADE
);

CREATE TABLE question (
	id SERIAL PRIMARY KEY,
	id_exam BIGINT,
	name TEXT,
	FOREIGN KEY (id_exam)
		REFERENCES exam(id)
			ON UPDATE CASCADE
			ON DELETE CASCADE
); 

CREATE TABLE choice (
	id SERIAL PRIMARY KEY,
	id_question BIGINT,
	name TEXT,
	correct BOOLEAN,
	FOREIGN KEY (id_question)
		REFERENCES question(id)
			ON UPDATE CASCADE
			ON DELETE CASCADE
);

CREATE TABLE exam_appuser_choice (
	id_exam BIGINT,
	id_appuser BIGINT,
	id_choice BIGINT,
	finished BOOLEAN,
	answer BOOLEAN,
	PRIMARY KEY (id_exam, id_appuser, id_choice),
	FOREIGN KEY (id_exam)
		REFERENCES exam(id)
			ON UPDATE CASCADE
			ON DELETE CASCADE,
	FOREIGN KEY (id_appuser) 
		REFERENCES appuser(id)
			ON UPDATE CASCADE
			ON DELETE CASCADE,
	FOREIGN KEY (id_choice)
		REFERENCES choice(id)
			ON UPDATE CASCADE
			ON DELETE CASCADE
);

